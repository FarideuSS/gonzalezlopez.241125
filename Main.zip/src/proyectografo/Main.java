package proyectografo;

public class Main {
    public static void main(String[] args) {
        GrafoRecursivo grafo = new GrafoRecursivo();

        System.out.println("Recorrido DFS (esperado A B D C):");
        grafo.dfs(0);
        System.out.println();

        grafo.resetVisitas();
        System.out.println("\nSegundo recorrido:");
        grafo.dfs(0);
    }
}
