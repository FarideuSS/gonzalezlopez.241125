package proyectografo;

public class GrafoRecursivo {

    private Nodo[] nodos;
    private int[][] adyacencia;

    public GrafoRecursivo() {

        nodos = new Nodo[4];
        nodos[0] = new Nodo("A");
        nodos[1] = new Nodo("B");
        nodos[2] = new Nodo("C");
        nodos[3] = new Nodo("D");

        adyacencia = new int[][]{
            {0, 1, 1, 0},
            {1, 0, 0, 1},
            {1, 0, 0, 1},
            {0, 1, 1, 0}
        };
    }

    public void dfs(int indice) {
        Nodo actual = nodos[indice];
        actual.visitado = true;
        System.out.print(actual.valor + " ");

        for (int i = 0; i < nodos.length; i++) {
            if (adyacencia[indice][i] == 1 && !nodos[i].visitado) {
                dfs(i);
            }
        }
    }

    public void resetVisitas() {
        for (Nodo n : nodos) {
            n.visitado = false;
        }
    }
}
