package proyectografo;

public class Nodo {
    public String valor;
    public boolean visitado;

    public Nodo(String valor) {
        this.valor = valor;
        this.visitado = false;
    }
}
